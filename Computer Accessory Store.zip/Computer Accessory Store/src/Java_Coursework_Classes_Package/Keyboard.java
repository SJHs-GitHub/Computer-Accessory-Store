package Java_Coursework_Classes_Package;

import Java_Coursework_ENUM_Package.Connectivity_ENUM;
import Java_Coursework_ENUM_Package.KeyboardType_ENUM;
import Java_Coursework_ENUM_Package.Layout_ENUM;

public class Keyboard extends Product {
	
	private Layout_ENUM layout;
	private KeyboardType_ENUM keyboardType;

	public Keyboard(int barcode, String brand, String colour, Connectivity_ENUM connectivity, int quantity, double originalCost, double retailPrice, Layout_ENUM layout, KeyboardType_ENUM keyboardType) {
		super(barcode, brand, colour, connectivity, quantity, originalCost, retailPrice);
		this.layout = layout;
		this.keyboardType = keyboardType;
	}

	public Layout_ENUM getLayout() {
		return this.layout;
	}

	public KeyboardType_ENUM getKeyboardType() {
		return this.keyboardType;
	}
	
	//override
	public String toString() {
		return (this.getBarcode()+", keyboard, "+this.getKeyboardType()+", "+this.getBrand()+", "+this.getColour()+", "+this.getConnectivity()+", "+this.getQuantity()+", "+this.getOriginalCost()+", "+this.getRetailPrice()+", "+this.getLayout());
	}
	
	//override
	//same as above but doesn't include original cost.
	public String toStringCustomer() {
		return (this.getBarcode()+", keyboard, "+this.getKeyboardType()+", "+this.getBrand()+", "+this.getColour()+", "+this.getConnectivity()+", "+this.getQuantity()+", "+this.getRetailPrice()+", "+this.getLayout());
	}

}

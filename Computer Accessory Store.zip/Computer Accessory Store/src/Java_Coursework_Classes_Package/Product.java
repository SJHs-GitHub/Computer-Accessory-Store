package Java_Coursework_Classes_Package;

import Java_Coursework_ENUM_Package.Connectivity_ENUM;

public abstract class Product {
	
	private int barcode;
	private String brand;
	private String colour;
	private Connectivity_ENUM connectivity;
	private int quantity;
	private double originalCost;
	private double retailPrice;
	
	public Product(int barcode, String brand, String colour, Connectivity_ENUM connectivity, int quantity, double originalCost, double retailPrice) {
		this.barcode = barcode;
		this.brand = brand;
		this.colour = colour;
		this.connectivity = connectivity;
		this.setQuantity(quantity);
		this.originalCost = originalCost;
		this.retailPrice = retailPrice;
	}

	public int getBarcode() {
		return this.barcode;
	}

	public String getBrand() {
		return this.brand;
	}

	public String getColour() {
		return this.colour;
	}

	public Connectivity_ENUM getConnectivity() {
		return this.connectivity;
	}

	public int getQuantity() {
		return this.quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getOriginalCost() {
		return this.originalCost;
	}

	public double getRetailPrice() {
		return this.retailPrice;
	}
	
	//abstract as overridden by each subclass differently.
	public abstract String toStringCustomer();
	
	//override
	//used to compare two products to see if they are the same.
	public boolean equals(Product prod2) {
		if (this.barcode == prod2.getBarcode()) {
			return true;
		}
		else {
			return false;
		}
	}
}

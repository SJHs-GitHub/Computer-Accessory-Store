package Java_Coursework_Classes_Package;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Java_Coursework_ENUM_Package.Connectivity_ENUM;
import Java_Coursework_ENUM_Package.KeyboardType_ENUM;
import Java_Coursework_ENUM_Package.Layout_ENUM;
import Java_Coursework_ENUM_Package.MouseType_ENUM;

public class Stock {
	
	private List<Product> stockList;
	
	public Stock(List<Product> stockList) {
		this.stockList = stockList;
	}

	public List<Product> getStockList() {
		return this.stockList;
	}
	
	public static Stock initialiseStock() throws FileNotFoundException {
		
		Stock stock = null;
		Mouse mouse = null;
		Keyboard keyboard = null;
		List<Product> stockList = new ArrayList<Product>();
		
		File stockFile = new File("Stock.txt");
		Scanner fileScanner = new Scanner(stockFile);
		
		while (fileScanner.hasNextLine()) {
			
			String line = fileScanner.nextLine();
			String[] splitLine = line.split(",");
			
			//if the line is for a mouse creates mouse object, if keyboard makes keyboard object.
			if ((splitLine[1].trim().toLowerCase()).equals("mouse")) {
				mouse = new Mouse(Integer.parseInt(splitLine[0].trim()), splitLine[3].trim(), splitLine[4].trim(), Connectivity_ENUM.valueOf(splitLine[5].trim()), Integer.parseInt(splitLine[6].trim()), Double.parseDouble(splitLine[7].trim()), Double.parseDouble(splitLine[8].trim()), Integer.parseInt(splitLine[9].trim()), MouseType_ENUM.valueOf(splitLine[2].trim()));
				stockList.add(mouse);
			}
			else {
				keyboard = new Keyboard(Integer.parseInt(splitLine[0].trim()), splitLine[3].trim(), splitLine[4].trim(), Connectivity_ENUM.valueOf(splitLine[5].trim()), Integer.parseInt(splitLine[6].trim()), Double.parseDouble(splitLine[7].trim()), Double.parseDouble(splitLine[8].trim()), Layout_ENUM.valueOf(splitLine[9].trim()), KeyboardType_ENUM.valueOf(splitLine[2].trim()));
				stockList.add(keyboard);
			}
		
		}
		
		stock = new Stock(stockList);
		
		fileScanner.close();
		
		return stock;
		
	}
	
	public static void addKeyboard(int barcode, String brand, String colour, Connectivity_ENUM connectivity, int quantity, double originalCost, double retailPrice, Layout_ENUM layout, KeyboardType_ENUM keyboardType) {
		
		FileWriter stockFile = null;
		try {
			stockFile = new FileWriter("stock.txt", true);
		} catch (IOException e) {
			e.printStackTrace();
		}
		BufferedWriter bw = new BufferedWriter(stockFile);
		try {
			bw.write("\n"+barcode+", keyboard, "+keyboardType+", "+brand+", "+colour+", "+connectivity+", "+quantity+", "+originalCost+", "+ retailPrice+", "+layout);
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void addMouse(int barcode, String brand, String colour, Connectivity_ENUM connectivity, int quantity, double originalCost, double retailPrice, int numButtons, MouseType_ENUM mouseType) {
		
		FileWriter stockFile = null;
		try {
			stockFile = new FileWriter("stock.txt", true);
		} catch (IOException e) {
			e.printStackTrace();
		}
		BufferedWriter bw = new BufferedWriter(stockFile);
		try {
			bw.write("\n"+barcode+", mouse, "+mouseType+", "+brand+", "+colour+", "+connectivity+", "+quantity+", "+originalCost+", "+ retailPrice+", "+numButtons);
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//after a purchase each product in the stockList is written to the stock file, so the quantities of the items that were sold are updated to reflect what was sold.
	public void updateStockFile() {
		
		FileWriter stockFile = null;
		try {
			stockFile = new FileWriter("stock.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
		BufferedWriter bw = new BufferedWriter(stockFile);
		
		int counter = 1;
		
		for (Product prod:stockList) {
			if (counter < (stockList.size())) {
				try {
					bw.write(prod.toString()+"\n");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			else {
				try {
					bw.write(prod.toString());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			counter++;
		}
		try {
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	//when an item is to be added to stock this method is called and it checks each item already in stock to see if any with the same barcode as the one that is to be added.
	public boolean uniqueStockCheck(int barcode) {
		boolean unique = true;
		for (Product prod:stockList) {
			if (barcode == prod.getBarcode()) {
				unique = false;
			}
		}
		return unique;
	}
}

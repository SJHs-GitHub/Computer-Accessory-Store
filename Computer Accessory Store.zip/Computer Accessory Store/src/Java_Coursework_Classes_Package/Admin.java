package Java_Coursework_Classes_Package;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Admin extends User {

	public Admin(int userID, String username, String surname, int houseNo, String postcode, String city) {
		super(userID, username, surname, houseNo, postcode, city);
	}
	
	public static Admin initialiseAdmin(String username) throws FileNotFoundException {
		
		Admin user = null;
		
		File userAccounts = new File("UserAccounts.txt");
		Scanner fileScanner = new Scanner(userAccounts);
		
		while (fileScanner.hasNextLine()) {
			
			String line = fileScanner.nextLine();
			String[] splitLine = line.split(",");
			
			//checks the current line is for the correct user. If it is creates an object of that user using data from the text file.
			if ((splitLine[1].trim()).equals(username)) {
				user = new Admin(Integer.parseInt(splitLine[0].trim()), splitLine[1].trim(), splitLine[2].trim(), Integer.parseInt(splitLine[3].trim()), splitLine[4].trim(), splitLine[5].trim());
			}	
		}
		fileScanner.close();
		return user;
	}
	
}

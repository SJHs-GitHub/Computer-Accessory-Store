package Java_Coursework_Classes_Package;

import Java_Coursework_ENUM_Package.Connectivity_ENUM;
import Java_Coursework_ENUM_Package.MouseType_ENUM;

public class Mouse extends Product {
	
	private int numOfButtons;
	private MouseType_ENUM mouseType;

	public Mouse(int barcode, String brand, String colour, Connectivity_ENUM connectivity, int quantity, double originalCost, double retailPrice, int numOfButtons, MouseType_ENUM mouseType) {
		super(barcode, brand, colour, connectivity, quantity, originalCost, retailPrice);
		this.numOfButtons = numOfButtons;
		this.mouseType = mouseType;
	}

	public int getNumOfButtons() {
		return this.numOfButtons;
	}

	public MouseType_ENUM getMouseType() {
		return this.mouseType;
	}
	
	//override
	public String toString() {
		return (this.getBarcode()+", mouse, "+this.getMouseType()+", "+this.getBrand()+", "+this.getColour()+", "+this.getConnectivity()+", "+this.getQuantity()+", "+this.getOriginalCost()+", "+this.getRetailPrice()+", "+this.getNumOfButtons());
	}
	
	//override
	//same as above but doesn't include original cost.
	public String toStringCustomer() {
		return (this.getBarcode()+", mouse, "+this.getMouseType()+", "+this.getBrand()+", "+this.getColour()+", "+this.getConnectivity()+", "+this.getQuantity()+", "+this.getRetailPrice()+", "+this.getNumOfButtons());
	}
	
}

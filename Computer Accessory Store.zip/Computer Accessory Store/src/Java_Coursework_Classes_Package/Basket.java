package Java_Coursework_Classes_Package;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Basket {
	
	private List<Product> basketList;
	private List<Integer> quantitiesList;
	
	public Basket(List<Product> basketList, List<Integer> quantitiesList) {
		this.basketList = basketList;
		this.quantitiesList = quantitiesList;
		
	}

	public List<Product> getBasketList() {
		return this.basketList;
	}

	public List<Integer> getQuantitiesList() {
		return this.quantitiesList;
	}

	public double getPrice() {
		double amount = 0;
		int counter = 0;
		// for each product in the basketList get the quantity that is being bought and get it's retail price and calculate total price for that item. The price for each item are summed to get total.
		for (Product prod:basketList) {
			amount+=((quantitiesList.get(counter))*(prod.getRetailPrice()));
			counter++;
		}
		return amount;
	}

	public void addToCart(Stock stock, int index, int quantityToPurchase, int availableQuantity) {
		int newQuantity = availableQuantity - quantityToPurchase;
		List<Product> stockList = stock.getStockList();
		this.basketList.add(stockList.get(index));
		this.quantitiesList.add(quantityToPurchase);
		stockList.get(index).setQuantity(newQuantity);
		//testing
		System.out.println();
		System.out.println();
		System.out.println();
		for (Product prod:basketList) {
			System.out.println(prod.toString());
		}
		//
	}
	
	public void saveForLater(User user) throws FileNotFoundException {
		
		int userID = user.getUserID();
		String postcode = user.getPostcode();
		Date objDate = new Date();
		SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
		String date = format1.format(objDate);
		//testing
		System.out.println(date); 
		//
		
		//so the new addition to activity log is at the top, first the old file is copied then the new line prepended to the old file's content and it is all written back to the file.
		File fileToCopy = new File("ActivityLog.txt");
		Scanner fileScanner = new Scanner(fileToCopy);
		String previousEntries = "";
		
		while (fileScanner.hasNextLine()) {
			String line = fileScanner.nextLine();
			previousEntries = previousEntries + line+"\n";
		}
		
		fileScanner.close();
		
		FileWriter activityLog = null;
		
		try {
			activityLog = new FileWriter("ActivityLog.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		BufferedWriter bw = new BufferedWriter(activityLog);
		
		int counter = 0;
		
		for (Product prod:basketList) {
			int barcode = prod.getBarcode();
			double retailPrice = prod.getRetailPrice();
			int quantity = quantitiesList.get(counter);
			try {
				bw.write(userID+", "+postcode+", "+barcode+", "+retailPrice+", "+quantity+", saved, "+date+"\n");
			} catch (IOException e) {
				e.printStackTrace();
			}
			counter++;
		}
		
		try {
			bw.write(previousEntries);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		try {
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void cancel(User user) throws FileNotFoundException {
		
		int userID = user.getUserID();
		String postcode = user.getPostcode();
		Date objDate = new Date();
		SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
		String date = format1.format(objDate);
		//testing
		System.out.println(date);
		//
		
		File fileToCopy = new File("ActivityLog.txt");
		Scanner fileScanner = new Scanner(fileToCopy);
		String previousEntries = "";
		
		while (fileScanner.hasNextLine()) {
			String line = fileScanner.nextLine();
			previousEntries = previousEntries + line+"\n";
		}
		
		fileScanner.close();
		
		FileWriter activityLog = null;
		
		try {
			activityLog = new FileWriter("ActivityLog.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		BufferedWriter bw = new BufferedWriter(activityLog);
		
		int counter = 0;
		
		for (Product prod:basketList) {
			int barcode = prod.getBarcode();
			double retailPrice = prod.getRetailPrice();
			int quantity = quantitiesList.get(counter);
			try {
				bw.write(userID+", "+postcode+", "+barcode+", "+retailPrice+", "+quantity+", cancelled, "+date+"\n");
			} catch (IOException e) {
				e.printStackTrace();
			}
			counter++;
		}
		
		try {
			bw.write(previousEntries);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		try {
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void pay(User user, Stock stock, String paymentMethod) throws FileNotFoundException {
		
		int userID = user.getUserID();
		String postcode = user.getPostcode();
		Date objDate = new Date();
		SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
		String date = format1.format(objDate);
		//testing
		System.out.println(date);
		//
		
		File fileToCopy = new File("ActivityLog.txt");
		Scanner fileScanner = new Scanner(fileToCopy);
		String previousEntries = "";
		
		while (fileScanner.hasNextLine()) {
			String line = fileScanner.nextLine();
			previousEntries = previousEntries + line+"\n";
		}
		
		fileScanner.close();
		
		FileWriter activityLog = null;
		
		try {
			activityLog = new FileWriter("ActivityLog.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		BufferedWriter bw = new BufferedWriter(activityLog);
		
		int counter = 0;
		
		for (Product prod:basketList) {
			int barcode = prod.getBarcode();
			double retailPrice = prod.getRetailPrice();
			int quantity = quantitiesList.get(counter);
			try {
				bw.write(userID+", "+postcode+", "+barcode+", "+retailPrice+", "+quantity+", purchased, "+paymentMethod+", "+date+"\n");
			} catch (IOException e) {
				e.printStackTrace();
			}
			counter++;
		}
		
		try {
			bw.write(previousEntries);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		try {
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		stock.updateStockFile();
	}
	
	//when an item is to be added to the basket this method is called and it checks each item already in the basket to see if any are the same as the one that is to be added.
	public boolean uniqueBasketCheck(Product productToBeTested) {
		boolean unique = true;
		for (Product prod:basketList) {
			if (productToBeTested.equals(prod)) {
				unique = false;
			}
		}
		return unique;
	}
}

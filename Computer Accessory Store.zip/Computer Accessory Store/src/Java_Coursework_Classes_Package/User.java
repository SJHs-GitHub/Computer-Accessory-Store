package Java_Coursework_Classes_Package;

public abstract class User {
	
	private int userID;
	private String username;
	private String surname;
	private int houseNo;
	private String postcode;
	private String city;
	
	public User(int userID, String username, String surname, int houseNo, String postcode, String city) {
		
		this.userID = userID;
		this.username = username;
		this.surname = surname;
		this.houseNo = houseNo;
		this.postcode = postcode;
		this.city = city;
		
	}

	public int getUserID() {
		return this.userID;
	}

	public String getUsername() {
		return this.username;
	}

	public String getSurname() {
		return this.surname;
	}

	public int getHouseNo() {
		return this.houseNo;
	}

	public String getPostcode() {
		return this.postcode;
	}

	public String getCity() {
		return this.city;
	}
	
	//override
	public String toString() {
		return (this.getUserID()+", "+this.getUsername()+", "+this.getSurname()+", "+this.getHouseNo()+", "+this.getPostcode()+", "+this.getCity());
	}
	
}

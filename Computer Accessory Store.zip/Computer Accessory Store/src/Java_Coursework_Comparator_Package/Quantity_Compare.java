package Java_Coursework_Comparator_Package;

import java.util.Comparator;
import Java_Coursework_Classes_Package.Product;

public class Quantity_Compare implements Comparator<Product>{
	
	public int compare(Product prod1, Product prod2) {
		if (prod1.getQuantity() < prod2.getQuantity()) {
			return 1;
		}
		if (prod1.getQuantity() > prod2.getQuantity()) {
			return -1;
		}
		else {
			return 0;
		}
	}
}

package Java_Coursework_ENUM_Package;

public enum KeyboardType_ENUM {
	standard,
	internet,
	gaming,
	flexible
}

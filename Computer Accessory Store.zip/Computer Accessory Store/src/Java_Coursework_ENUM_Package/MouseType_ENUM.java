package Java_Coursework_ENUM_Package;

public enum MouseType_ENUM {
	standard,
	gaming
}

package Java_Coursework_ENUM_Package;

public enum Connectivity_ENUM {
	wired,
	wireless
}

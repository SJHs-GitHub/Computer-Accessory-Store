package Java_Coursework_ENUM_Package;

public enum Layout_ENUM {
	US,
	UK
}

package Java_Coursework_GUI_Package;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;

import Java_Coursework_Classes_Package.*;

public class Admin_Main_Page extends JFrame {

	private JPanel contentPane;
	private Admin user = null;
	private Stock stock = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_Main_Page frame = new Admin_Main_Page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin_Main_Page() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton addKeyboardButton = new JButton("Add Keyboard");
		addKeyboardButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.setVisible(false);
				dispose();
				Add_Keyboard_Page newFrame = new Add_Keyboard_Page();
				newFrame.setVisible(true);
				newFrame.setStock(stock);
			}
		});
		addKeyboardButton.setBounds(767, 53, 193, 43);
		contentPane.add(addKeyboardButton);
		
		JButton addMouseButton = new JButton("Add Mouse");
		addMouseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.setVisible(false);
				dispose();
				Add_Mouse_Page newFrame = new Add_Mouse_Page();
				newFrame.setVisible(true);
				newFrame.setStock(stock);
			}
		});
		addMouseButton.setBounds(767, 111, 193, 43);
		contentPane.add(addMouseButton);
		
		JLabel stockLabel = new JLabel("Stock");
		stockLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		stockLabel.setBounds(10, 11, 76, 31);
		contentPane.add(stockLabel);
		
		JButton logOutButton = new JButton("Log Out");
		logOutButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.setVisible(false);
				dispose();
				Login_Page.main(null);
			}
		});
		logOutButton.setBounds(767, 407, 193, 43);
		contentPane.add(logOutButton);
	}
	
	public void setAdmin(Admin user) {
		this.user = user;
		//testing
		System.out.println(this.user.toString());
		System.out.println();
		//
	}
	
	public void setStock(Stock stock) {
		this.stock = stock;
		List<Product> stockList = this.stock.getStockList();
		
		//testing
		for(Product prod : stockList) {
			System.out.println(prod.toString());
		}
		System.out.println();
		//
		
		JList stockJList = new JList();
		stockJList.setSelectedIndex(0);
		stockJList.setBounds(10, 53, 732, 397);
		contentPane.add(stockJList);
		DefaultListModel DLM = new DefaultListModel();
		for(Product prod : stockList) {
			DLM.addElement(prod.toString());
		}
		stockJList.setModel(DLM);
	}
}

package Java_Coursework_GUI_Package;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Java_Coursework_Classes_Package.Basket;
import Java_Coursework_Classes_Package.Customer;
import Java_Coursework_Classes_Package.Stock;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class Pay_PayPal_Page extends JFrame {

	private JPanel contentPane;
	private JTextField emailTextField;
	private Customer user = null;
	private Stock stock = null;
	private Basket basket = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Pay_PayPal_Page frame = new Pay_PayPal_Page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Pay_PayPal_Page() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel emailLabel = new JLabel("Email");
		emailLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		emailLabel.setBounds(197, 149, 56, 22);
		contentPane.add(emailLabel);
		
		JLabel payWithPayPalLabel = new JLabel("Pay with PayPal");
		payWithPayPalLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		payWithPayPalLabel.setBounds(269, 50, 144, 88);
		contentPane.add(payWithPayPalLabel);
		
		emailTextField = new JTextField();
		emailTextField.setBounds(269, 142, 240, 42);
		contentPane.add(emailTextField);
		emailTextField.setColumns(10);
		
		JTextArea errorText = new JTextArea();
		errorText.setBounds(583, 142, 144, 42);
		contentPane.add(errorText);
		
		JButton placeOrderButton = new JButton("Place Order");
		placeOrderButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				errorText.setText(" ");
				String email = emailTextField.getText();
				int emailIndex = email.indexOf("@");
				if (emailIndex > -1) {
					try {
						basket.pay(user,  stock, "PayPal");
					} catch (FileNotFoundException e1) {
						e1.printStackTrace();
					}
					contentPane.setVisible(false);
					dispose();
					After_PayPal_Page newFrame = new After_PayPal_Page();
					newFrame.setVisible(true);
					newFrame.setBasket(basket);
				}
				else {
					errorText.setText("Please enter a valid\nemail (includes '@').");
				}
			}
		});
		placeOrderButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		placeOrderButton.setBounds(269, 222, 157, 77);
		contentPane.add(placeOrderButton);
	}
	
	public void setCustomer(Customer user) {
		this.user = user;
	}
	
	public void setStock(Stock stock) {
		this.stock = stock;
	}
	
	public void setBasket(Basket basket) {
		this.basket  = basket;
	}

}

package Java_Coursework_GUI_Package;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import Java_Coursework_Classes_Package.*;
import Java_Coursework_Comparator_Package.Quantity_Compare;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.awt.event.ActionEvent;

public class Login_Page {

	private JFrame frame;
	private Admin user1 = null;
	private Customer user2 = null;
	private Stock stock = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login_Page window = new Login_Page();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login_Page() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 1000, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel welcomeLabel = new JLabel("Welcome to the Computer Accessory Shop\r\n");
		welcomeLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		welcomeLabel.setBounds(350, 11, 266, 81);
		frame.getContentPane().add(welcomeLabel);
		
		JLabel selectUserLabel = new JLabel("Please Select a User to Sign in as");
		selectUserLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		selectUserLabel.setBounds(381, 66, 192, 52);
		frame.getContentPane().add(selectUserLabel);
		
		JLabel adminLabel = new JLabel("Admin\r\n");
		adminLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		adminLabel.setBounds(350, 180, 36, 14);
		frame.getContentPane().add(adminLabel);
		
		JLabel customerLabel = new JLabel("Customer\r\n");
		customerLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		customerLabel.setBounds(561, 175, 55, 24);
		frame.getContentPane().add(customerLabel);
		
		JButton adminButton = new JButton("user1");
		adminButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					user1 = Admin.initialiseAdmin("user1");
					stock = Stock.initialiseStock();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				
				Quantity_Compare quantCompare = new Quantity_Compare();
				Collections.sort(stock.getStockList(), quantCompare);
				
				//testing
				List<Product> stockList = stock.getStockList();
				for(Product prod : stockList) {
					System.out.println(prod.toString());
				}
				System.out.println();
				//
				
				frame.dispose();
				Admin_Main_Page newFrame = new Admin_Main_Page();
				newFrame.setVisible(true);
				newFrame.setAdmin(user1);
				newFrame.setStock(stock);
			}
		});
		adminButton.setBounds(325, 235, 89, 23);
		frame.getContentPane().add(adminButton);
		
		JButton customerButton1 = new JButton("user2");
		customerButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					user2 = Customer.initialiseCustomer("user2");
					stock = Stock.initialiseStock();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				
				Quantity_Compare quantCompare = new Quantity_Compare();
				Collections.sort(stock.getStockList(), quantCompare);
				
				//testing
				List<Product> stockList = stock.getStockList();
				for(Product prod : stockList) {
					System.out.println(prod.toString());
				}
				System.out.println();
				//
				
				frame.dispose();
				Customer_Main_Page newFrame = new Customer_Main_Page();
				newFrame.setVisible(true);
				newFrame.setCustomer(user2);
				newFrame.setStock(stock);
			}
		});
		customerButton1.setBounds(548, 235, 89, 23);
		frame.getContentPane().add(customerButton1);
		
		JButton customerButton2 = new JButton("user3");
		customerButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					user2 = Customer.initialiseCustomer("user3");
					stock = Stock.initialiseStock();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				
				Quantity_Compare quantCompare = new Quantity_Compare();
				Collections.sort(stock.getStockList(), quantCompare);
				
				//testing
				List<Product> stockList = stock.getStockList();
				for(Product prod : stockList) {
					System.out.println(prod.toString());
				}
				System.out.println();
				//
				
				frame.dispose();
				Customer_Main_Page newFrame = new Customer_Main_Page();
				newFrame.setVisible(true);
				newFrame.setCustomer(user2);
				newFrame.setStock(stock);
			}
		});
		customerButton2.setBounds(548, 303, 89, 23);
		frame.getContentPane().add(customerButton2);
		
		JButton customerButton3 = new JButton("user4");
		customerButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					user2 = Customer.initialiseCustomer("user4");
					stock = Stock.initialiseStock();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				
				Quantity_Compare quantCompare = new Quantity_Compare();
				Collections.sort(stock.getStockList(), quantCompare);
				
				//testing
				List<Product> stockList = stock.getStockList();
				for(Product prod : stockList) {
					System.out.println(prod.toString());
				}
				System.out.println();
				//
				
				frame.dispose();
				Customer_Main_Page newFrame = new Customer_Main_Page();
				newFrame.setVisible(true);
				newFrame.setCustomer(user2);
				newFrame.setStock(stock);
			}
		});
		customerButton3.setBounds(548, 368, 89, 23);
		frame.getContentPane().add(customerButton3);
	}
}

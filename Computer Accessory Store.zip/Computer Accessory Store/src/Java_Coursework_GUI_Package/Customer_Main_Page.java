package Java_Coursework_GUI_Package;

import java.awt.BorderLayout;

import Java_Coursework_Classes_Package.*;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JLabel;
import java.awt.Font;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;

public class Customer_Main_Page extends JFrame {

	private JPanel contentPane;
	private Customer user = null;
	private Stock stock = null;
	private Basket basket = null;
	private JTextField filterBrandNameEntry;
	private JTextField quantityEntry;
	private JList stockJList = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Customer_Main_Page frame = new Customer_Main_Page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Customer_Main_Page() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel stockLabel = new JLabel("Stock");
		stockLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		stockLabel.setBounds(40, 21, 46, 14);
		contentPane.add(stockLabel);
		
		JLabel filterLabel = new JLabel("Filter By:");
		filterLabel.setBounds(40, 46, 65, 14);
		contentPane.add(filterLabel);
		
		JButton filterButton_UK = new JButton("UK Layout Keyboard");
		filterButton_UK.setBounds(104, 42, 149, 23);
		contentPane.add(filterButton_UK);
		
		JButton filterButton_Brand = new JButton("Brand Name");
		filterButton_Brand.setBounds(285, 42, 109, 23);
		contentPane.add(filterButton_Brand);
		
		filterBrandNameEntry = new JTextField();
		filterBrandNameEntry.setBounds(464, 43, 122, 20);
		contentPane.add(filterBrandNameEntry);
		filterBrandNameEntry.setColumns(10);
		
		JTextArea userInfoTextArea = new JTextArea();
		userInfoTextArea.setBounds(710, 81, 245, 132);
		contentPane.add(userInfoTextArea);
		
		JLabel filterBrandNameLabel = new JLabel("Name:");
		filterBrandNameLabel.setBounds(416, 46, 38, 14);
		contentPane.add(filterBrandNameLabel);
		
		JLabel quantityToAddLabel = new JLabel("Quantity:");
		quantityToAddLabel.setBounds(710, 224, 78, 14);
		contentPane.add(quantityToAddLabel);
		
		stockJList = new JList();
		stockJList.setSelectedIndex(0);
		stockJList.setBounds(40, 80, 640, 355);
		contentPane.add(stockJList);
		
		JButton addToCartButton = new JButton("Add to Cart");
		addToCartButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int index = stockJList.getSelectedIndex();
				// error catching if they have selected an element of JList and have entered a correct quantity.
				if ((index == -1)||(quantityEntry.getText().isEmpty())) {
					userInfoTextArea.setText("Please select a product and enter the \nquantity you wish to purchase \nbefore adding to cart.");
				}
				else {
					userInfoTextArea.setText(" ");
					//catches type errors on input quantity
					boolean proceed = true;
					
					try {
						int quantityToPurchase = Integer.parseInt(quantityEntry.getText());
					}
					catch (Exception exception){
						userInfoTextArea.setText("Please enter an integer for quantity.");
						proceed = false;
					}
					
					if (proceed == true) {
						int quantityToPurchase = Integer.parseInt(quantityEntry.getText());
						
						if (quantityToPurchase == 0) {
							userInfoTextArea.setText("Please enter a value for quantity \n that is not 0, and is in stock.");
						}
						else {
							userInfoTextArea.setText(" ");
							List<Product> stockList = stock.getStockList();
							int availableQuantity = stockList.get(index).getQuantity();
							if (availableQuantity < quantityToPurchase) {
								userInfoTextArea.setText("The quantity you've entered is not \n available. Please enter a value for quantity \n that we have in stock.");
							}
							else {
								userInfoTextArea.setText(" ");
								// error catching so they can't add the same barcode to the basket more than once.
								boolean unique = basket.uniqueBasketCheck(stockList.get(index));
								if (unique == true) {
									//now add it to the basket by calling Basket object's method
									basket.addToCart(stock, index, quantityToPurchase, availableQuantity);
									Product prodToDisplay = user.showLastItemAddedToBasket(basket);
									userInfoTextArea.setText("Last item added to cart:\n"+prodToDisplay.getBarcode());
									
									//testing
									List<Integer> qantList = basket.getQuantitiesList();
									System.out.println();
									System.out.println();
									for (Product prod:stockList) {
										System.out.println(prod.toString());
									}
									for(Integer i : qantList) {
										System.out.println(i);
									}
									System.out.println();
									System.out.println();
									List<Product> basketList = basket.getBasketList();
									for (Product prod:basketList) {
										System.out.println(prod.toString());
									}
									//
								}
								else {
									userInfoTextArea.setText("You have already added this product \nto the basket, and as such cannot do so \nagain.");
								}
							}
						}
					}
				}
			}
		});
		addToCartButton.setBounds(857, 220, 97, 23);
		contentPane.add(addToCartButton);
		
		quantityEntry = new JTextField();
		quantityEntry.setBounds(769, 221, 78, 20);
		contentPane.add(quantityEntry);
		quantityEntry.setColumns(10);
		
		JButton payCardButton = new JButton("Pay - Credit Card");
		payCardButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.setVisible(false);
				dispose();
				Pay_Card_Page newFrame = new Pay_Card_Page();
				newFrame.setVisible(true);
				newFrame.setCustomer(user);
				newFrame.setStock(stock);
				newFrame.setBasket(basket);
			}
		});
		payCardButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		payCardButton.setBounds(710, 259, 245, 37);
		contentPane.add(payCardButton);
		
		JButton payPaypalButton = new JButton("Pay - PayPal");
		payPaypalButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.setVisible(false);
				dispose();
				Pay_PayPal_Page newFrame = new Pay_PayPal_Page();
				newFrame.setVisible(true);
				newFrame.setCustomer(user);
				newFrame.setStock(stock);
				newFrame.setBasket(basket);
			}
		});
		payPaypalButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		payPaypalButton.setBounds(710, 307, 245, 37);
		contentPane.add(payPaypalButton);
		
		JButton saveForLaterButton = new JButton("Save For Later");
		saveForLaterButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					basket.saveForLater(user);
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				contentPane.setVisible(false);
				dispose();
				Login_Page.main(null);
			}
		});
		saveForLaterButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		saveForLaterButton.setBounds(710, 355, 245, 37);
		contentPane.add(saveForLaterButton);
		
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					basket.cancel(user);
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				contentPane.setVisible(false);
				dispose();
				Login_Page.main(null);
			}
		});
		cancelButton.setFont(new Font("Tahoma", Font.ITALIC, 11));
		cancelButton.setBounds(708, 403, 247, 32);
		contentPane.add(cancelButton);
		
		JButton logOutButton = new JButton("Log Out");
		logOutButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.setVisible(false);
				dispose();
				Login_Page.main(null);
			}
		});
		logOutButton.setBounds(710, 23, 245, 37);
		contentPane.add(logOutButton);
	}
	
	public void setCustomer(Customer user) {
		this.user = user;
		System.out.println(this.user.toString());
		System.out.println();
	}
	
	public void setStock(Stock stock) {
		this.stock = stock;
		List<Product> stockList = this.stock.getStockList();
		
		//testing
		for(Product prod : stockList) {
			System.out.println(prod.toString());
		}
		System.out.println();
		//
		
		DefaultListModel DLM = new DefaultListModel();
		for(Product prod : stockList) {
			DLM.addElement(prod.toStringCustomer());
		}
		stockJList.setModel(DLM);
		
		List<Product> basketList = new ArrayList<Product>();
		List<Integer> quantitiesList = new ArrayList<Integer>();
		
		basket = new Basket(basketList, quantitiesList);
	}
}

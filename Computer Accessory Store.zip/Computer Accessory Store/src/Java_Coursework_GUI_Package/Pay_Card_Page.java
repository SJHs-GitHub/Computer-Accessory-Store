package Java_Coursework_GUI_Package;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Java_Coursework_Classes_Package.*;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class Pay_Card_Page extends JFrame {

	private JPanel contentPane;
	private JTextField cardNumTextField;
	private JTextField secNumTextField;
	private Customer user = null;
	private Stock stock = null;
	private Basket basket = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Pay_Card_Page frame = new Pay_Card_Page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Pay_Card_Page() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel cardNumLabel = new JLabel("Card Number");
		cardNumLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		cardNumLabel.setBounds(137, 146, 120, 28);
		contentPane.add(cardNumLabel);
		
		JLabel secNumLabel = new JLabel("Security Number");
		secNumLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		secNumLabel.setBounds(105, 193, 152, 36);
		contentPane.add(secNumLabel);
		
		cardNumTextField = new JTextField();
		cardNumTextField.setBounds(282, 145, 367, 36);
		contentPane.add(cardNumTextField);
		cardNumTextField.setColumns(10);
		
		secNumTextField = new JTextField();
		secNumTextField.setBounds(282, 196, 86, 36);
		contentPane.add(secNumTextField);
		secNumTextField.setColumns(10);
		
		JLabel payCardLabel = new JLabel("Pay With Card");
		payCardLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		payCardLabel.setBounds(282, 73, 128, 28);
		contentPane.add(payCardLabel);
		
		JTextArea errorText = new JTextArea();
		errorText.setBounds(712, 146, 231, 83);
		contentPane.add(errorText);
		
		JButton placeOrderButton = new JButton("Place Order");
		placeOrderButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				errorText.setText(" ");
				long cardNo;
				int secNo;
				boolean proceed = true;
				try {
					cardNo = Long.parseLong(cardNumTextField.getText());
					secNo = Integer.parseInt(secNumTextField.getText());
				}
				catch (Exception eee) {
					errorText.setText("Card Number should be 16 digits\nSecurity number should be 3 digits\nPlease check they are correct.");
					proceed = false;
				}
				if (proceed) {
					cardNo = Long.parseLong(cardNumTextField.getText());
					secNo = Integer.parseInt(secNumTextField.getText());
					System.out.println((String.valueOf(cardNo)).length());
					System.out.println((String.valueOf(secNo)).length());
		
					if ((String.valueOf(cardNo)).length() == 16 & (String.valueOf(secNo)).length() == 3) {
						try {
							basket.pay(user,  stock, "Credit Card");
						} catch (FileNotFoundException e1) {
							e1.printStackTrace();
						}
						contentPane.setVisible(false);
						dispose();
						After_PayCard_Page newFrame = new After_PayCard_Page();
						newFrame.setVisible(true);
						newFrame.setBasket(basket);
					}
					else {
						errorText.setText("Card Number should be 16 digits\nSecurity number should be 3 digits\nPlease check they are correct.");
					}
				}
			}
		});
		placeOrderButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		placeOrderButton.setBounds(282, 274, 166, 77);
		contentPane.add(placeOrderButton);
		
	}
	
	public void setCustomer(Customer user) {
		this.user = user;
	}
	
	public void setStock(Stock stock) {
		this.stock = stock;
	}
	
	public void setBasket(Basket basket) {
		this.basket  = basket;
	}
}

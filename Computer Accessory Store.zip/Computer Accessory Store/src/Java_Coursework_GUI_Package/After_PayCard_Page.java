package Java_Coursework_GUI_Package;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Java_Coursework_Classes_Package.Basket;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class After_PayCard_Page extends JFrame {

	private JPanel contentPane;
	private Basket basket = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					After_PayCard_Page frame = new After_PayCard_Page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public After_PayCard_Page() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel paidByLabel = new JLabel("Paid by Credit Card");
		paidByLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		paidByLabel.setBounds(262, 229, 171, 22);
		contentPane.add(paidByLabel);
		
		JButton continueButton = new JButton("Continue");
		continueButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPane.setVisible(false);
				dispose();
				Login_Page.main(null);
			}
		});
		continueButton.setBounds(262, 284, 89, 23);
		contentPane.add(continueButton);
	}
	
	public void setBasket(Basket basket) {
		this.basket  = basket;
		JLabel amountLabel = new JLabel(String.format("� %.2f", basket.getPrice()));
		amountLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		amountLabel.setBounds(172, 217, 80, 47);
		contentPane.add(amountLabel);
	}

}

package Java_Coursework_GUI_Package;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Java_Coursework_Classes_Package.Stock;
import Java_Coursework_ENUM_Package.Connectivity_ENUM;
import Java_Coursework_ENUM_Package.KeyboardType_ENUM;
import Java_Coursework_ENUM_Package.Layout_ENUM;
import Java_Coursework_ENUM_Package.MouseType_ENUM;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Add_Mouse_Page extends JFrame {
	
	private JPanel contentPane;
	private JTextField barcodeEntry;
	private JTextField brandEntry;
	private JTextField colourEntry;
	private JTextField connecEntry;
	private JTextField quantEntry;
	private JTextField originalCostEntry;
	private JTextField retailEntry;
	private JTextField numButtonsEntry;
	private JTextField mouseTypeEntry;
	private Stock stock = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_Mouse_Page frame = new Add_Mouse_Page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_Mouse_Page() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel barcodeLabel = new JLabel("Barcode");
		barcodeLabel.setBounds(50, 75, 60, 14);
		contentPane.add(barcodeLabel);
		
		JLabel brandLabel = new JLabel("Brand");
		brandLabel.setBounds(50, 115, 46, 14);
		contentPane.add(brandLabel);
		
		JLabel colourLabel = new JLabel("Colour");
		colourLabel.setBounds(50, 154, 46, 14);
		contentPane.add(colourLabel);
		
		JLabel connecLabel = new JLabel("Connectivity");
		connecLabel.setBounds(50, 195, 82, 14);
		contentPane.add(connecLabel);
		
		JLabel quantityLabel = new JLabel("Quantity in Stock");
		quantityLabel.setBounds(50, 237, 112, 14);
		contentPane.add(quantityLabel);
		
		JLabel origCostLabel = new JLabel("Original Cost");
		origCostLabel.setBounds(50, 279, 82, 14);
		contentPane.add(origCostLabel);
		
		JLabel retailPriceLabel = new JLabel("Retail Price");
		retailPriceLabel.setBounds(50, 322, 82, 14);
		contentPane.add(retailPriceLabel);
		
		JLabel numButtonsLabel = new JLabel("Number of Buttons");
		numButtonsLabel.setBounds(50, 365, 112, 14);
		contentPane.add(numButtonsLabel);
		
		JLabel MouseTypeLabel = new JLabel("Mouse Type");
		MouseTypeLabel.setBounds(50, 405, 82, 14);
		contentPane.add(MouseTypeLabel);
		
		barcodeEntry = new JTextField();
		barcodeEntry.setBounds(172, 72, 86, 20);
		contentPane.add(barcodeEntry);
		barcodeEntry.setColumns(10);
		
		brandEntry = new JTextField();
		brandEntry.setBounds(172, 112, 86, 20);
		contentPane.add(brandEntry);
		brandEntry.setColumns(10);
		
		colourEntry = new JTextField();
		colourEntry.setBounds(172, 151, 86, 20);
		contentPane.add(colourEntry);
		colourEntry.setColumns(10);
		
		connecEntry = new JTextField();
		connecEntry.setBounds(172, 192, 86, 20);
		contentPane.add(connecEntry);
		connecEntry.setColumns(10);
		
		quantEntry = new JTextField();
		quantEntry.setBounds(172, 234, 86, 20);
		contentPane.add(quantEntry);
		quantEntry.setColumns(10);
		
		originalCostEntry = new JTextField();
		originalCostEntry.setBounds(172, 276, 86, 20);
		contentPane.add(originalCostEntry);
		originalCostEntry.setColumns(10);
		
		retailEntry = new JTextField();
		retailEntry.setBounds(172, 319, 86, 20);
		contentPane.add(retailEntry);
		retailEntry.setColumns(10);
		
		numButtonsEntry = new JTextField();
		numButtonsEntry.setBounds(172, 362, 86, 20);
		contentPane.add(numButtonsEntry);
		numButtonsEntry.setColumns(10);
		
		mouseTypeEntry = new JTextField();
		mouseTypeEntry.setBounds(172, 402, 86, 20);
		contentPane.add(mouseTypeEntry);
		mouseTypeEntry.setColumns(10);
		
		JTextArea errorTextArea = new JTextArea();
		errorTextArea.setBounds(334, 70, 208, 118);
		contentPane.add(errorTextArea);
		
		JLabel addToStockLabel = new JLabel("Add Mouse to Stock");
		addToStockLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		addToStockLabel.setBounds(50, 30, 197, 20);
		contentPane.add(addToStockLabel);
		
		JButton addToStockButton = new JButton("Add to Stock");
		addToStockButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				errorTextArea.setText(" ");
				try {
					int barcode = Integer.parseInt(barcodeEntry.getText());
					String brand = brandEntry.getText();
					String colour = colourEntry.getText();
					Connectivity_ENUM connectivity = Connectivity_ENUM.valueOf(connecEntry.getText());
					int quantity = Integer.parseInt(quantEntry.getText());
					double originalCost = Double.parseDouble(originalCostEntry.getText());
					double retailPrice = Double.parseDouble(retailEntry.getText());
					int numButtons = Integer.parseInt(numButtonsEntry.getText());
					MouseType_ENUM mouseType = MouseType_ENUM.valueOf(mouseTypeEntry.getText());
					
					boolean unique = stock.uniqueStockCheck(barcode);
					if (unique == true) {
						Stock.addMouse(barcode, brand, colour, connectivity, quantity, originalCost, retailPrice, numButtons, mouseType);
						
						contentPane.setVisible(false);
						dispose();
						Login_Page.main(null);
					}
					else {
						errorTextArea.setText("This barcode already exists in Stock.\nPlease enter a unique barcode.");
					}
				}
				catch(Exception except) {
					errorTextArea.setText("One or more inputs are invalid. \nPlease make sure inputs \nare valid (type, value etc.).");
				}
			}
		});
		addToStockButton.setBounds(50, 441, 208, 20);
		contentPane.add(addToStockButton);
	}
	
	public void setStock(Stock stock) {
		this.stock = stock;
	}

}
